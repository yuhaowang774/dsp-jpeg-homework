# 基于分块DCT的JPEG图像压缩实现与率失真分析

这是DSP大作业的第一轮可运行原型。核心算法自行编写，所有MATLAB文件均有中文函数说明和关键步骤注释；没有直接移植网上编解码项目。

## 一键运行

在本机 **MATLAB R2024b** 中把当前文件夹切换到本目录，然后执行：

```matlab
% 执行自测、数据准备、120组实验、绘图和实验纪要生成。
result = run_project;
```

程序仅使用基础MATLAB。不要求Image Processing Toolbox、Signal Processing Toolbox或Communications Toolbox。已保存的`data/`输入请随程序保留；首次运行用到MATLAB自带`peppers.png`。不需要联网。

单独处理自己的灰度PNG：

```matlab
% 核心输入必须是二维uint8；输出是真正的基线JPEG，而非改后缀的MAT文件。
addpath('src');
image = imread('data/peppers_gray.png');
info = jpeg_encode_gray(image,'my_result.jpg',50,'jpeg');
[reconstructed,details] = jpeg_decode_gray('my_result.jpg');
% 独立检查标准解码器是否能读取，不参与自编解码流程。
independent = imread('my_result.jpg');
```

只运行测试：

```matlab
% 测试非8倍数尺寸、极端亮度、随机纹理、ZRL、FF填充和错误文件等。
addpath('src','tests');
tests = run_tests;
```

## 已实现范围

1. 8×8正交DCT/IDCT矩阵、边缘复制补齐、电平平移。
2. T.81附录K亮度示例表和等步长对照表；常见IJG整数Q映射。
3. Zigzag、DC差分、AC零游程、EOB/ZRL、幅值映射、规范Huffman编码。
4. SOI/APP0(JFIF)/DQT/SOF0/DHT/SOS/EOI、字节填充和实际`.jpg`文件写入。
5. 从文件重新解析表并自编熵解码、反量化、IDCT；不复用编码端量化系数重建。
6. 独立使用`imread`检查自编文件可读性、尺寸和像素差。

当前范围仅为8位灰度、单分量、基线单扫描。彩色、渐进式、重启间隔和通用文件容错尚未实现；自编解码器遇到不支持的格式会报错。

## 实验设计

- 输入：MATLAB辣椒照片的灰度中心裁剪，以及明确标注为合成的渐变、纹理、文字图；均256×256。
- Q：5、10、20、35、50、65、80、90、95、100。
- 方法：自编频率加权、自编等步长、MATLAB `imwrite`基线；共120个文件。
- 实测：完整字节数、bpp、压缩比、MSE、PSNR、MAE、稀疏度、熵位数、读写耗时等。
- 等码率：在加权与等步长曲线共同覆盖范围内线性插值，明确标记为估计，不外推、不冒充实测。
- 不默认“加权一定更好”，不把同Q比较当成等码率比较。

## 文件导航

| 位置 | 内容 |
|---|---|
| `run_project.m` | 一键运行 |
| `src/jpeg_encode_gray.m` | 自编编码器 |
| `src/jpeg_read_scan.m`、`src/jpeg_decode_gray.m` | 文件解析及自编解码 |
| `src/jpeg_tables.m`、`src/jpeg_huffman.m` | 标准常量、DCT、扫描和规范码 |
| `src/jpeg_quant_table.m` | 可编辑的量化策略 |
| `src/run_experiments.m` | 批量实验及MATLAB基线 |
| `tests/run_tests.m` | 自动验证 |
| `results/第一轮实验纪要.md` | 从实测数据生成的中文报告 |
| `results/figures/` | 答辩用PNG/PDF图 |
| `results/encoded/` | 实际JPEG文件 |
| `data/manifest.csv` | 输入来源 |

## 答辩时必须说清楚

- DCT本身不丢信息，量化才是主要有损步骤，熵编码无损。
- 压缩比基准为原始灰度像素字节数，不是输入PNG文件大小。
- 实际文件大小包含表、标记、填充；极小图可能不压反涨。
- Q不是“画质百分比”；Q=100不保证逐像素无损。
- 图像内容影响压缩表现；PSNR不等价于人类观感。
- 本轮是一张自然照片加三张合成图的可行性验证，不可夸大为普遍结论。
- 组员分工、姓名及成绩权重待你们实际协商后填写，程序不虚构这些信息。

## 参考依据与来源

1. ITU-T Recommendation T.81 (1992), *Digital compression and coding of continuous-tone still images — Requirements and guidelines*，重点为基线编码和附录K示例表：<https://www.w3.org/Graphics/JPEG/itu-t81.pdf>。
2. G. K. Wallace, *The JPEG Still Picture Compression Standard*, Communications of the ACM, 34(4), 1991, pp.30–44，DOI: 10.1145/103085.103089。
3. MathWorks, *Discrete Cosine Transform*，教学背景：<https://www.mathworks.com/help/images/discrete-cosine-transform.html>。本项目不依赖该页工具箱函数。
4. libjpeg-turbo, `src/jcparam.c`，核对常见IJG质量映射（整数除法）；只参考参数约定，不复制其实现：<https://github.com/libjpeg-turbo/libjpeg-turbo/blob/main/src/jcparam.c>。

`peppers.png`为本机MATLAB附带示例素材，并非本项目原创图像。衍生灰度裁剪仅用于本机教学实验；对外公开或提交前请核对素材许可，或替换为自己的照片。其余三张测试图由代码生成。JPEG常量是公开标准表，不应宣称为原创算法。
